#include <iostream>
#include "mystring.h"
#include <typeinfo>

int main(int argc, char **argv)
{
    learn::String s1(""); // 不是调用默认构造函数
    learn::String s2("hello");
    learn::String *p = new learn::String("world");

    std::cout << std::endl;
    s1.check();
    s2.check();
    p->check();

    std::cout << std::endl;
    learn::String s3 = s2;// 使用了拷贝构造函数
    learn::String s4(s3);// 与s3一样使用了拷贝构造函数

    std::cout << std::endl;
    s4 = *p;// 拷贝赋值
    s4 = s4;

    std::cout << s2 << " " << *p <<std::endl;
    delete p;
    return 0;
}