#include <iostream>
#include "account.h"

int main(int argc, char **argv)
{
    learn::Account::showCurrentRate(); // 静态函数的调用方式1-通过class name调用

    learn::Account::set_rate(5.0);
    learn::Account::showCurrentRate();

    learn::Account xiaoming;
    xiaoming.set_rate(7.0); // 静态函数的调用方式2-通过object调用
    learn::Account::showCurrentRate();

    learn::Account::m_rate = 9.0;
    learn::Account::showCurrentRate();

    return 0;
}