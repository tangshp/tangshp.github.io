#ifndef _MYSTRINGDELEGATION_H_
#define _MYSTRINGDELEGATION_H_

namespace learn
{
    class StringDe;
    class StringRep{
        friend class StringDe;
        StringRep(const char* s);
        ~StringRep();
        int count;// 引用计数器
        char *rep;
    };
    
    class StringDe{
        public:
            StringDe();
            StringDe(const char *s);
            StringDe(const StringDe& s);
            StringDe& operator=(const StringDe& s);
            ~StringDe();
        private:
            StringReq* rep; // pimpl - Pointer to Implementation
    };
}   
#endif
