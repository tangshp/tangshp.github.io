#include "fileSystem.h"
#include <iostream>
int main(int argc, char **argv)
{
    learn::Primitive fileSystem_h("fileSystem.h");
    learn::Primitive fileSystem_cpp("fileSystem.cpp");
    learn::Primitive CMakeLists_txt("CMakeLists.txt");

    learn::Composite fileSystem_dir("fileSystem");

    fileSystem_dir.add(&fileSystem_h);
    fileSystem_dir.add(&fileSystem_cpp);
    fileSystem_dir.add(&CMakeLists_txt);

    // ------------------------------------------------
    learn::Primitive fileSystem_main_cpp("fileSystem_main.cpp");

    learn::Composite learn_dir("00-learn");

    learn_dir.add(&fileSystem_dir);
    learn_dir.add(&fileSystem_main_cpp);

    learn_dir.tree();
    return 0;
}