#ifndef _QUEUE_H_
#define _QUEUE_H_
#include <iostream>

namespace learn{

template<class T>
struct Itr
{
    T* cur;
    T* first;
    T* last;
    T** node;
};

template <class T>
class deque
{
    public:
        deque(){ std::cout << "deque ctor." << std::endl;}
        ~deque(){ std::cout << "deque dctor." << std::endl;}
    protected:
        Itr<T> start;
        Itr<T> finish;
        T** map;
        unsigned int map_size;
};

template <class T, class Sequence = deque<T>>
class queue{
    protected:
        Sequence c;// 复合 has-a
    public:
        queue(){ std::cout << "queue ctor." << std::endl; }
        ~queue(){ std::cout << "queue dctor." << std::endl; }
        bool empty() const {return c.empty();}
        size_t size() const {return c.size();}
        
        void push(const T& x){c.push_back(x);}
        void pop(){c.pop_front();}
};
}
#endif