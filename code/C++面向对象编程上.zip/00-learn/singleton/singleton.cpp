#include "singleton.h"

namespace learn
{
    A &A::getInstance()
    {
        static A a;
        return a;
    }

}