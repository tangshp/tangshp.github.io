#ifndef _SINGLETON_H_
#define _SINGLETON_H_

/*
 * 单例设计模式
 */
namespace learn
{
    class A;

    class A
    {
    public:
        static A &getInstance();
        void setup() {}

    private:
        A() {}
        A(const A &rhs) {}
    };
}
#endif