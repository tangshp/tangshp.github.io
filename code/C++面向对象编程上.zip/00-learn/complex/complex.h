#ifndef _Complex_H_
#define _Complex_H_

#include <cmath>
// #include <ostream>

namespace learn
{
    class ostream;
    // 模板类声明格式
    template <class T>
    class Complex;

    // 模板函数声明格式-这是友元模板函数::第 1 步
    template <typename T>
    Complex<T> &__doapl(Complex<T> *ths, const Complex<T> &r);

    template <typename T>
    Complex<T> &__doasu(Complex<T> *ths, const Complex<T> &r);

    template <typename T>
    Complex<T> &__doamu(Complex<T> *ths, const Complex<T> &r);

    template <typename T>
    Complex<T> &__doadi(Complex<T> *ths, const Complex<T> &r);

    template <typename T>
    class Complex
    {

    public:
        // 构造函数1-指定默认实参
        Complex(T r = 0, T i = 0) : re(r), im(i)
        {
        }

        // 构造函数2-这种构造函数与构造函数1冲突
        // Complex() : re(0), im(0) {}

        // 构造函数3-针对非指针类型的类, 编译器会生成的拷贝构造函数(Complex<double> c1(c0))够用(指针类不适用)

        // 拷贝赋值-针对非指针类型的类, 编译器会生成拷贝赋值函数(Complex<double> c2(); c2=c1;)够用(指针类不适用)

        // const表示不能通过this来修改对象的数据
        T real() const { return re; }
        T imag() const { return im; }

        // this 对象直接访问 另外一个(同类型)对象的private数据, 相同class的各对象互为friends
        T func(const Complex<T> &param) const
        {
            return param.re + param.im;
        }

        // ==========================================================================================================
        // 成员函数重载
        Complex<T> &operator+=(const Complex<T> &rhs)
        {
            return __doapl(this, rhs);
        }

        Complex<T> &operator-=(const Complex<T> &rhs)
        {
            return __doasu(this, rhs);
        }

        Complex<T> &operator*=(const Complex<T> &rhs)
        {
            return __doamu(this, rhs);
        }

        Complex<T> &operator/=(const Complex<T> &rhs)
        {
            return __doadi(this, rhs);
        }

        // ==========================================================================================================
        Complex<T> operator+(const Complex<T> &rhs) const
        {
            return Complex<T>(this->re + rhs.re, this->im + rhs.im); // 这里会创建一个临时变量, 所以返回值是return by value
        }

        // typename() 创建临时对象(temp object)
        // 复数 + 实数
        Complex<T> operator+(double re) const
        {
            return Complex<T>(this->re + re, this->im); // 这里会创建一个临时变量, 所以返回值是return by value
        }

        // ==========================================================================================================
        // 是否相等-复数==复数
        bool operator==(const Complex<T> &rhs) const
        {
            return this->re == rhs.re && this->im == rhs.im;
        }
        // 复数==实数
        bool operator==(double re) const
        {
            return this->re == re && this->im == 0;
        }

    private:
        T re, im;

        // ==========================================================================================================

        // 这是友元模板函数(告诉编译器__doapl是我这个类的友元, 那么可以在该函数中直接访问该类的private数据或方法)::第 2 步
        template <typename U>
        friend Complex<U> &__doapl(Complex<U> *, const Complex<U> &);

        template <typename U>
        friend Complex<U> &__doasu(Complex<U> *, const Complex<U> &);

        template <typename U>
        friend Complex<U> &__doamu(Complex<U> *, const Complex<U> &);

        template <typename U>
        friend Complex<U> &__doadi(Complex<U> *, const Complex<U> &);

        // ==========================================================================================================
        // 重载
        template <typename U>
        friend std::ostream &operator<<(std::ostream &os, const Complex<U> &rhs);

        // 实数 + 复数
        template <typename U>
        friend Complex<U> operator+(double re, const Complex<U> &rhs);

        // ==========================================================================================================
        // 取反
        template <typename U>
        friend Complex<U> operator-(const Complex<U> &rhs);
    };

    // ==========================================================================================================
    // 这是友元模板函数(必须定义在.h文件中)::第 3 步
    // inline和模板函数的格式
    template <typename T>
    inline Complex<T> &__doapl(Complex<T> *ths, const Complex<T> &r)
    {
        ths->re += r.re;
        ths->im += r.im;
        return *ths; // 传递着无需知道接收者以reference形式接收
    }

    template <typename T>
    inline Complex<T> &__doasu(Complex<T> *ths, const Complex<T> &r)
    {
        ths->re -= r.re;
        ths->im -= r.im;
        return *ths; // 传递着无需知道接收者以reference形式接收
    }

    // (a+bi)(c+di) = (ac-bd)+ (ad+bc)i
    template <typename T>
    inline Complex<T> &__doamu(Complex<T> *ths, const Complex<T> &r)
    {
        T re = ths->re * r.re - ths->im * r.im; // ac-bd
        T im = ths->re * r.im + ths->im * r.re; // ad+bc
        ths->re = re;
        ths->im = im;
        return *ths; // 传递着无需知道接收者以reference形式接收
    }

    // (a+bi)/(c+di) = (a+bi)(c-di)/[(c+di)(c-di)]=(a+bi)(c-di)/[c^2-cdi+cdi+d^2]
    template <typename T>
    inline Complex<T> &__doadi(Complex<T> *ths, const Complex<T> &r)
    {
        Complex<T> &molecular = __doamu(ths, r);
        T denominator = r.re * r.re + r.im * r.im;
        ths->re /= denominator;
        ths->im /= denominator;
        return *ths; // 传递着无需知道接收者以reference形式接收
    }

    // ==========================================================================================================
    // 尽管该函数定义在learn作用域内,但是os是std作用域内定义的
    template <typename U>
    inline std::ostream &operator<<(std::ostream &os, const learn::Complex<U> &rhs)
    {
        os << "(" << rhs.re << ", " << rhs.im << "i)";
        return os;
    }

    // 实数 + 复数
    template <typename U>
    Complex<U> operator+(double re, const Complex<U> &rhs)
    {
        return Complex<U>(re + rhs.re, rhs.im);
    }

    template <typename U>
    Complex<U> operator-(const Complex<U> &rhs)
    {
        return Complex<U>(-rhs.re, -rhs.im);
    }


    
} // end namespace learn

#endif