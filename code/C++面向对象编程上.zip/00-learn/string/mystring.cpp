#include "mystring.h"
#include <cstring>
#include <iostream>

namespace learn
{
    // 构造函数1-通过c指针构造
    String::String(const char *cstr)
    {
        std::cout << "use ctor-1(common ctor)." << std::endl;
        if (cstr)
        {
            std::cout << "create " << (strlen(cstr) + 1) << " bytes" << std::endl;
            m_data = new char[strlen(cstr) + 1];
            strcpy(m_data, cstr);
        }
        else
        {
            std::cout << "create 1 bytes" << std::endl;
            m_data = new char[1];
            *m_data = '\0';
        }
    }

    // 构造函数2-通过其它 String 构造(拷贝构造)
    String::String(const String &str)
    {
        std::cout << "use ctor-2(copy ctor)." << std::endl;
        m_data = new char[strlen(str.m_data) + 1];
        strcpy(m_data, str.m_data);
    }

    // 拷贝赋值 - Big Three-2
    String &String::operator=(const String &str)
    {
        std::cout << "copy assignment." << std::endl;
        if (this->m_data == str.m_data) // 避免自我赋值
        {
            std::cout << "copy assignment self." << std::endl;
            return *this;
        }

        delete[] m_data;                           // 释放本身
        m_data = new char[strlen(str.m_data) + 1]; // 分配空间
        strcpy(m_data, str.m_data);                // 拷贝
        return *this;
    }

    String::~String()
    {
        if (m_data)
        {
            std::cout << "free it[" << m_data << "]" << std::endl;
            delete[] m_data;
        }
    }

    void String::check() const
    {
        if (m_data)
        {
            std::cout << m_data << std::endl;
        }
        else
        {
            std::cout << "empty" << std::endl;
        }
    }

    std::ostream &operator<<(std::ostream &os, const String &str)
    {
        return os << str.m_data;
    }

} // namespace learn
