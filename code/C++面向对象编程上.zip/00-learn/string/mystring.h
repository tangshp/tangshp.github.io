#ifndef _MYSTRING_H_
#define _MYSTRING_H_

#include <ostream>

namespace learn
{
    class ostream;

    class String
    {
    public:
        // 构造函数1-通过c指针构造
        String(const char *cstr = 0);

        // 有些书籍把拷贝构造/拷贝赋值/析构函数称为Big Three

        // 构造函数2-通过其它 String 构造(拷贝构造) - Big Three-1
        String(const String &str);

        // 拷贝赋值 - Big Three-2
        String &operator=(const String &str);

        // 析构函数 - Big Three-2
        ~String();

        char *c_str() const { return m_data; }

        void check() const;

    private:
        char *m_data;

        friend std::ostream &operator<<(std::ostream &os, const String &str);
    };

} // end namespace learn
#endif