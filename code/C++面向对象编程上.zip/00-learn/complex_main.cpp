#include <iostream>
#include "complex.h"
#include "mystring.h"
#include "singleton.h"

int main(int argc, char **argv)
{
    learn::Complex<double> c1(2.5, 1.5);
    learn::Complex<double> c2;
    learn::Complex<double> c3();
    learn::Complex<double> c4(9.0, 9.0);


    const learn::Complex<int> c5;

    std::cout << c5 + 5 << std::endl;

    learn::Complex<double> *p = new learn::Complex<double>(4);

    std::cout << c1.imag() << std::endl;
    std::cout << c1.real() << std::endl;
    std::cout << c5.imag() << std::endl;
    std::cout << c5.real() << std::endl;

    learn::__doapl(&c4, c1);
    std::cout << "c4:" << c4.imag() << std::endl;
    std::cout << "c4:" << c4.real() << std::endl;
    std::cout << c1.func(c4) << std::endl;

    std::cout << c4 << std::endl;
    auto copyC4 = c4;
    c4 += c1;
    std::cout << c4 << " = " << copyC4 << " + " << c1 << std::endl;

    learn::Complex<double> c6(1, 1);
    learn::Complex<double> c7(1, -1);
    auto copyC6 = c6;
    c6 *= c7;
    std::cout << c6 << " = " << copyC6 << " * " << c7 << std::endl;

    learn::Complex<double> c8(1.0, 1.0);
    learn::Complex<double> c9(1.0, -1.0);
    learn::Complex<double> copyC8 = c8;
    c8 /= c9;
    std::cout << c8 << " = " << copyC8 << " / " << c9 << std::endl;
    // (1+1i)/(1-1i) = (1+1i)(1+1i)/[1+1]=(1+2i-1)/[2]
    std::cout << (c8 + c9) << " = " << c8 << " + " << c9 << std::endl;

    std::cout << "c8 is " << c8 << std::endl;
    std::cout << "-c8 is " << -c8 << std::endl;

    std::cout << (9 + c8) << " = " << 9 << " + " << c8 << std::endl;
    if (c8 == c8)
    {
        std::cout << "equal " << std::endl;
    }
    else
    {
        std::cout << "not equal " << std::endl;
    }

    learn::A::getInstance().setup();
    auto &refA = learn::A::getInstance();
    auto &refB = learn::A::getInstance();
    std::cout << "address of refA : " << &refA << std::endl;
    std::cout << "address of refB : " << &refB << std::endl;

    // learn::Complex<double> *pc = new learn::Complex<double>(1, 2);
    learn::String *pc = new learn::String("4654654Hello");
    // std::cout << sizeof(*pc) << std::endl;
    // 编译器会把上面的初始化转化为以下三个动作:
    // Complex* pc;
    // 1、分配内存
    // void *mem = operator new(sizeof(Complex))  函数operator new内部调用malloc实现
    // 2、转型
    // pc = static_cast<Complex*>(mem)
    // 3、构造函数
    // pc->Complex::Complex(1,2) => Complex::Complex(pc, 1, 2)
    delete pc;
    // 编译器把上面的delete分解为以下两个动作:
    // 1、调用默认的析构函数
    // String::~String(pc) 该析构函数释放了pc指向的对象中成员m_data指向的内存
    // 2、释放内存(释放pc指针指向String对象的内存-该内存的大小即指针m_data本身的大小-8bytes)
    return 0;
}