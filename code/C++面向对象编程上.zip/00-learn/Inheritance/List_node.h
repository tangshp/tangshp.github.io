#ifndef _LIST_NODE_H_
#define _LIST_NODE_H_
#include <iostream>
namespace learn
{
    struct _List_node_base
    {
        _List_node_base(){std::cout << "_List_node_base ctor."<< std::endl;}
        ~_List_node_base(){std::cout << "_List_node_base dctor."<< std::endl;}
        _List_node_base *_M_next;
        _List_node_base *_M_prev;
    };
    
    template<typename _Tp>
    struct _List_node: public _List_node_base
    {
        _List_node(){std::cout << "_List_node ctor."<< std::endl;}
        ~_List_node(){std::cout << "_List_node dctor."<< std::endl;}

        _Tp _M_data;
    };
}

#endif