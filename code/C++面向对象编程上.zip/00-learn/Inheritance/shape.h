#ifndef _MYSHAPE_H_
#define _MYSHAPE_H_

#include <iostream>

namespace learn
{
    struct Coordinate
    {
        unsigned int x;
        unsigned int y;
        Coordinate(unsigned int x_arg = 0, unsigned int y_arg = 0) : x(x_arg), y(y_arg)
        {
            std::cout << "Coordinate ctor." << std::endl;
        }
        ~Coordinate() { std::cout << "Coordinate dtor." << std::endl; }
    };

    class Shape
    {
    private:
        static unsigned int id;

    public:
        Shape() : idx(id)
        {
            id++;
            std::cout << "shape cotr" << std::endl;
        }
        int objectID() const; // 非虚函数
        void plot(const Coordinate &pos);
        virtual void error(const std::string &msg) const;   // 虚函数
        virtual void draw(const Coordinate &pos) const = 0; // 纯虚函数
        virtual ~Shape() { std::cout << "Shape dtor" << std::endl; }

    public:
        unsigned int idx;
    };

    class Rectangle : public Shape
    {
    public:
        Rectangle(unsigned int w, unsigned int h) : _M_w(w), _M_h(h)
        {
            std::cout << "Rectangle ctor :: idx :: " << this->idx << " Rectangle::width:" << _M_w << " height:" << _M_h << std::endl;
        }
        // 纯虚函数必须重新定义, 否则报错
        //  error: invalid cast to abstract class type 'learn::Rectangle'
        void draw(const Coordinate &pos) const;

        ~Rectangle() { std::cout << "Rectangle dtor" << std::endl; }

    private:
        unsigned int _M_w;
        unsigned int _M_h;
        Coordinate pos;
    };

    class Ellipse : public Shape
    {
    public:
        Ellipse(unsigned int w, unsigned int h) : _M_w(w), _M_h(h)
        {
            std::cout << "idx :: " << this->idx << " Ellipse::width:" << _M_w << " height:" << _M_h << std::endl;
        }
        virtual void draw(const Coordinate &pos) const;
        void error(const std::string &msg) const;

        ~Ellipse() { std::cout << "Ellipse dtor" << std::endl; }

    private:
        unsigned int _M_w;
        unsigned int _M_h;
    };

    void testEasyX();
}

#endif