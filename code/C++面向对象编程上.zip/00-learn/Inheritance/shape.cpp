#include "shape.h"
#include <graphics.h>
#include <conio.h>

// https://docs.easyx.cn/zh-cn/intro

namespace learn
{

    std::ostream &operator<<(std::ostream &os, const Coordinate &pos)
    {
        return os << "[" << pos.x << ", " << pos.y << "]";
    }

    // static成员变量定义是不能由static
    unsigned int Shape::id = 1;

    // 不是纯虚函数必须定义否则报错
    void Shape::error(const std::string &msg) const
    {
        std::cout << "shape error[" << msg << "]." << std::endl;
    }

    void Shape::plot(const Coordinate &pos)
    {
        std::cout << "plot at " << pos << "." << std::endl;
        draw(pos);
    }

    // 纯虚函数必须重新定义, 否则报错
    //  error: invalid cast to abstract class type 'learn::Rectangle'
    void Rectangle::draw(const Coordinate &pos) const
    {
        rectangle(pos.x - _M_w / 2, pos.y - _M_h / 2, pos.x + _M_w / 2, pos.y + _M_h / 2);
    }

    void Ellipse::draw(const Coordinate &pos) const
    {
        ellipse(pos.x - _M_w / 2, pos.y - _M_h / 2, pos.x + _M_w / 2, pos.y + _M_h / 2);
    }

    void Ellipse::error(const std::string &msg) const
    {
        std::cout << "plot ellipse error, no get position" << std::endl;
    }

}