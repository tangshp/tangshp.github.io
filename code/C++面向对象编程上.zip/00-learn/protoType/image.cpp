#include "image.h"

namespace learn
{
    // 静态成员变量初始化
    Image *Image::_prototypes[10] = {NULL};
    int Image::_nextSlot; // 全局变量初始值为空

    LandSatImage LandSatImage::_landSatImage; // 调用私有构造函数
    int LandSatImage::_count = 1;

    SpotImage SpotImage::_spotImage;
    int SpotImage::_count = 1;
};
