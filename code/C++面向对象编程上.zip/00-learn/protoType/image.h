#ifndef _IMAGE_H_
#define _IMAGE_H_
#include <iostream>

namespace learn
{
    enum ImageType
    {
        LSAT,
        SPOT
    };

    class Image
    {
    public:
        virtual void draw() = 0;
        static Image *findAndClone(ImageType type)
        {
            for (size_t i = 0; i < _nextSlot; i++)
            {
                if (_prototypes[i]->returnType() == type)
                {
                    return _prototypes[i]->clone();
                }
            }
        }

    protected:
        virtual ImageType returnType() = 0;
        virtual Image *clone() = 0;

        static void addProtoType(Image *image)
        {
            _prototypes[_nextSlot++] = image;
        }

    private:
        static Image *_prototypes[10];
        static int _nextSlot;
    };

    class LandSatImage : public Image
    {
    public:
        ImageType returnType()
        {
            return LSAT;
        }

        void draw()
        {
            std::cout << "LandSatImage::draw" << std::endl;
        }

        Image *clone()
        {
            std::cout << "Image *clone()" << std::endl;
            return new LandSatImage(1);
        }

    protected:
        LandSatImage(int dummy)
        { // dummy 参数根本用不到, 只是为了和private区分
            std::cout << "LandSatImage(int dummy)" << std::endl;
            _id = _count++;
        }

    private:
        LandSatImage()
        {
            std::cout << "LandSatImage()" << std::endl;
            addProtoType(this);
        }

        int _id;
        static int _count;
        static LandSatImage _landSatImage;
    };

    class SpotImage : public Image
    {
    public:
        ImageType returnType()
        {
            return SPOT;
        }

        void draw()
        {
            std::cout << "SpotImage::draw" << std::endl;
        }

        Image *clone()
        {
            std::cout << "Image *clone()" << std::endl;
            return new SpotImage(1);
        }

    protected:
        SpotImage(int dummy)
        { // dummy 参数根本用不到, 只是为了和private区分
            std::cout << "SpotImage(int dummy)" << std::endl;
            _id = _count++;
        }

    private:
        SpotImage()
        {
            std::cout << "SpotImage()" << std::endl;
            addProtoType(this);
        }

        int _id;
        static int _count;
        static SpotImage _spotImage;
    };
}

#endif