#include "List_node.h"
#include "shape.h"
#include <graphics.h>
#include <conio.h>

int main(int argc, char **argv)
{
    // learn::_List_node<int> list_node;

    // learn::testEasyX();
    initgraph(640, 480);
    setbkcolor(WHITE);
    setcolor(BLACK);
    cleardevice();

    learn::Rectangle rect(90, 50);
    // rect.plot(learn::Coordinate(640 / 2 - 100, 480 / 2));
    // std::cout << std::endl;

    // learn::Ellipse ellipse(90, 50);
    // ellipse.plot(learn::Coordinate(640 / 2 + 100, 480 / 2));

    getch();
    closegraph();

    std::cout << std::endl;

    return 0;
}