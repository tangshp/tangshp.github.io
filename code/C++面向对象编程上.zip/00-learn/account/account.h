#ifndef _ACCOUNT_H_
#define _ACCOUNT_H_

namespace learn
{
    class Account
    {
    public:
        // 静态成员数据是所有对象共有的,内存上唯独一份
        static double m_rate;

        // 静态函数没有this指针
        static void set_rate(const double &x) { m_rate = x; }

    public:
        Account(/* args */);
        ~Account();

        static void showCurrentRate();
    };

}
#endif