#include "account.h"
#include <iostream>

namespace learn
{

    double Account::m_rate = 8.0; // 定义-此时才为该类的静态成员数据分配内存(此时设不设置初值无所谓)

    Account::Account(/* args */)
    {
    }

    Account::~Account()
    {
    }

    void Account::showCurrentRate()
    {
        std::cout << "current rate is " << m_rate << "." << std::endl;
    }

}