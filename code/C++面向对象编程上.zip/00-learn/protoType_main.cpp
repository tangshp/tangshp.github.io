#include "image.h"
using namespace learn;
const int NUM_IMAGES = 8;
ImageType input[NUM_IMAGES] = {LSAT, SPOT, SPOT, SPOT, LSAT, SPOT, SPOT, LSAT};

int main(int argc, char **argv)
{
    Image *images[NUM_IMAGES];
    std::cout << std::endl;

    for (size_t i = 0; i < NUM_IMAGES; i++)
    {
        images[i] = Image::findAndClone(input[i]);
    }

    std::cout << std::endl;
    for (size_t i = 0; i < NUM_IMAGES; i++)
    {
        images[i]->draw();
    }
    std::cout << std::endl;

    for (size_t i = 0; i < NUM_IMAGES; i++)
    {
        delete images[i];
    }

    return 0;
}