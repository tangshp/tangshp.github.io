#ifndef _FILESYSTEM_H_
#define _FILESYSTEM_H_

#include <vector>
#include <iostream>
#include <string>

namespace learn
{
    class Component
    {
    public:
        Component(const char *name) : m_name(name) {}
        virtual void add(Component *c) {}
        virtual void tree(const int level = -1, const int curLevel = 1) const
        {
            std::cout << " - " << m_name << std::endl;
        }

        const std::string &name() const { return m_name; }

    private:
        std::string m_name;
    };

    class Primitive : public Component
    {
    public:
        Primitive(const char *name) : Component(name) {}
    };

    class Composite : public Component
    {
    public:
        Composite(const char *name) : Component(name) {}
        virtual void add(Component *c)
        {
            if (NULL == c)
            {
                return;
            }
            m_c.push_back(c);
        }

        virtual void tree(const int level = -1, const int curLevel = 1) const
        {
            // 文件夹
            std::cout << " d " << name() << std::endl;

            if (-1 != level && curLevel > level)
            { // 如果不要打印文件夹的子级文件, 这直接返回
                return;
            }
            const int nextLevel = curLevel + 1;
            // 文件夹下的文件或者目录
            for (size_t i = 0; i < m_c.size(); i++)
            {
                for (size_t j = 0; j < curLevel; j++)
                {
                    std::cout << "    ";
                }
                m_c[i]->tree(level, nextLevel);
            }
        }

    private:
        std::vector<Component *> m_c;
    };

}

#endif