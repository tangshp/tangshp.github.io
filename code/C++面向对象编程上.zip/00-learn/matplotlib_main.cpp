#include "matplotlib.h"

int main(int argc, char **argv)
{
    learn::Subject<int> sub(300, 500, 400);

    learn::Canvas::initCanvas(1120, 460);

    learn::Scatter sca(learn::Coordinate(30, 30), 500, 400);
    sub.attach(&sca);

    learn::Bar bar(learn::Coordinate(500 + 2 * 30, 30), 500, 400);
    sub.attach(&bar);

    sub.notify();

    learn::Canvas::spin();
    return 0;
}