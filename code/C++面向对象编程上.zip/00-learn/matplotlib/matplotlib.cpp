#include "matplotlib.h"

namespace learn
{
    unsigned int Canvas::width = 0;
    unsigned int Canvas::height = 0;

};