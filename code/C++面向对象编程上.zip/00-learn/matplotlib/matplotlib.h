#ifndef _MATPLOTLIB_H_
#define _MATPLOTLIB_H_

#include <vector>
#include <iostream>
#include <graphics.h>
#include <conio.h>
#include <time.h>

namespace learn
{

    class Observer;

    template <typename T>
    class Subject
    {
    public:
        Subject(const std::vector<T> &Xdata) : m_Xarray(Xdata)
        {
        }
        Subject(const std::vector<T> &Xdata, const std::vector<T> &Ydata) : m_Xarray(Xdata), m_Yarray(Ydata)
        {
        }

        void initSample(unsigned int n, unsigned int w, unsigned int h)
        {
            srand((unsigned)time(NULL));
            m_Xarray.resize(0);
            m_Yarray.resize(0);
            for (size_t i = 0; i < n; i++)
            {
                m_Xarray.push_back(rand() % w);
                m_Yarray.push_back(rand() % h);
            }
        }

        Subject(unsigned int n, unsigned int w, unsigned int h)
        {
            initSample(n, w, h);
        }

        ~Subject() {}

        void attach(Observer *obs)
        {
            if (NULL == obs)
            {
                return;
            }
            m_views.push_back(obs);
        }

        void notify() const
        {
            for (size_t i = 0; i < m_views.size(); i++)
            {
                m_views[i]->plot(this);
            }
        }

        size_t size() const { return m_Xarray.size(); }

    public:
        std::vector<T> m_Xarray;
        std::vector<T> m_Yarray;
        std::vector<Observer *> m_views;
    };

    struct Coordinate
    {
        Coordinate(unsigned int w, unsigned int h) : x(w), y(h)
        {
        }
        unsigned int x;
        unsigned int y;
    };

#define TickLenght 5

    class Canvas
    {
    public:
        Canvas() : anchor(0, 0), range(1920, 1080) {}
        Canvas(const Coordinate &coord, unsigned int w, unsigned int h) : anchor(coord), range(w, h) {}

        void plot(const Subject<int> *sub)
        {
            rectangle(anchor.x, anchor.y, anchor.x + range.x, anchor.y + range.y);
            plot_XTicks();
            plot_YTicks();
            update(sub);
        }

        virtual void update(const Subject<int> *sub) = 0;

        void plot_XTicks() const
        {
            for (auto x : xTicks)
            {
                line(anchor.x + x, anchor.y + range.y, anchor.x + x, anchor.y + range.y - TickLenght);
            }
        }

        void plot_YTicks() const
        {
            for (auto y : yTicks)
            {
                line(anchor.x, anchor.y + range.y - y, anchor.x + TickLenght, anchor.y + range.y - y);
            }
        }

        void set_xTicks(const std::vector<int> &ticks)
        {
            xTicks = ticks;
        }

        void set_xTicks(unsigned int step)
        {
            xTicks.resize(0);
            unsigned int curX = 0;
            while (curX < range.x)
            {
                xTicks.push_back(curX);
                curX += step;
            }
        }

        void set_yTicks(unsigned int step)
        {
            yTicks.resize(0);
            unsigned int curY = 0;
            while (curY < range.y)
            {
                yTicks.push_back(curY);
                curY += step;
            }
        }

        static void initCanvas(unsigned int w, unsigned int h)
        {
            if (0 == width && 0 == height)
            {
                initgraph(w, h);
                setbkcolor(WHITE);
                setcolor(BLACK);
                cleardevice();
                width = w;
                height = h;
            }
        }

        static void closeCanvas()
        {
            if (0 != width && 0 != height)
            {
                closegraph();
                width = 0;
                height = 0;
            }
        }

        static void spin()
        {
            if (0 != width && 0 != height)
                getch();
        }

    public:
        // 画布中大小
        static unsigned int width;
        static unsigned int height;

    public:
        Coordinate anchor; // Figure左上角坐标
        Coordinate range;  // Figure宽和高
        std::vector<int> xTicks;
        std::vector<int> yTicks;
    };

    class Observer : public Canvas
    {
    public:
        Observer()
        {
        }
        Observer(const Coordinate &coord, unsigned int w, unsigned int h) : Canvas(coord, w, h)
        {
            set_xTicks(25);
            set_yTicks(25);
        }
        ~Observer()
        {
        }
        virtual void update(const Subject<int> *sub) = 0;
    };

    class Scatter : public Observer
    {
    public:
        Scatter(const Coordinate &coord, unsigned int w, unsigned int h) : Observer(coord, w, h) {}
        virtual void update(const Subject<int> *sub)
        {
            setfillcolor(BLACK);
            for (size_t i = 0; i < sub->size(); i++)
            {
                solidcircle(sub->m_Xarray[i] + anchor.x, anchor.y + range.y - sub->m_Yarray[i], 2);
            }
        }
    };

    class Bar : public Observer
    {
    public:
        Bar(const Coordinate &coord, unsigned int w, unsigned int h) : Observer(coord, w, h), max_value(0) {}
        virtual void update(const Subject<int> *sub)
        {
            updateData(sub);
            setfillcolor(BLACK);
            float radio = 0.8 * range.y / max_value;
            for (size_t i = 0; i < xTicks.size(); i++)
            {
                fillBar(m_data[i] * radio, i * xTicks[1]);
            }
        }

        void updateData(const Subject<int> *sub)
        {
            m_data.resize(xTicks.size());
            size_t idx = 0;
            for (size_t i = 0; i < sub->size(); i++)
            {
                idx = sub->m_Xarray[i] / xTicks[1];
                m_data[idx]++;
                if (m_data[idx] > max_value)
                {
                    max_value = m_data[idx];
                }
            }
        }

        void fillBar(const size_t height, const size_t left_x) const
        {
            fillrectangle(anchor.x + left_x + 1, anchor.y + range.y - height,
                          anchor.x + left_x + xTicks[1] - 1, anchor.y + range.y);
        }

    private:
        std::vector<int> m_data;
        int max_value;
    };
}
#endif