#include <iostream>
#include "queue.h"

int main(int argc, char **argv)
{
    learn::queue<int> q;
    return 0;
}