#include <error.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <errno.h>
#include "readfile.h"
#include <stdio.h>
#include <unistd.h>

bool usage(int argc, char **argv)
{
    if (argc != 2)
    {
        error(EXIT_FAILURE, 0, "Usage: %s file-name", argv[0]);
        return false;
    }
    return true;
}

int read_obj(char **argv)
{
    int fd = -1;
    if ((fd = open(argv[1], O_RDONLY)) < 0)
    {
        error(EXIT_FAILURE, errno, "open %s failed", argv[1]);
        return fd;
    }
    return fd;
}

bool getStat(int fd, struct stat *pStat, char **argv)
{
    if (fstat(fd, pStat) < 0)
    {
        error(EXIT_FAILURE, errno, "get file %s info err", argv[1]);
    }
    printf("size of \"%s\": %ld bytes\n", argv[1], pStat->st_size);
    return true;
}

char *mmapHelper(size_t fsize, int fd, char **argv)
{
    char *file_mmbase = NULL;
    file_mmbase = mmap(NULL, fsize, PROT_READ, MAP_PRIVATE, fd, (off_t)0);
    if (MAP_FAILED == file_mmbase)
    {
        error(EXIT_FAILURE, errno, "mmap file %s err", argv[1]);
    }
    return file_mmbase;
}

bool readyExit(char *file_mmbase, size_t fsize, int fd)
{
    (void)munmap(file_mmbase, fsize);
    (void)close(fd);
}