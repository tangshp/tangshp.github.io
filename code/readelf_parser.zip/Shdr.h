#include <stddef.h>

const char *getSectionName(const char *file_mmbase, size_t i);
void printElf_Shdr(const char *file_mmbase, uint16_t secNum);
const Elf64_Shdr *getElf64_Shdr(const char *file_mmbase, size_t i);