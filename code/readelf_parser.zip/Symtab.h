#include <elf.h>
uint16_t getNumofSymbol(const Elf64_Shdr *pElf64_Shdr_symtab);
const Elf64_Sym *getElf64_Sym(const char *file_mmbase, const Elf64_Shdr *pElf64_Shdr_symtab);
void printElf64_Sym(const Elf64_Sym *pElf64_Sym, uint16_t numSymbol, const char *symbolHeader);
const char *getSymbolHeader(const char *file_mmbase, const Elf64_Shdr *pElf64_Shdr_strtab);