#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>

char *mmapHelper(size_t fsize, int fd, char **argv);
bool getStat(int fd, struct stat *pStat, char **argv);
int read_obj(char **argv);
bool usage(int argc, char **argv);
bool readyExit(char *file_mmbase, size_t fsize, int fd);