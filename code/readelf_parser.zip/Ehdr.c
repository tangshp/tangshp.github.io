#include <stdio.h>
#include "Ehdr.h"

void printElf_Ehdr(const Elf64_Ehdr *pElf64_Ehdr)
{
    if (NULL == pElf64_Ehdr)
    {
        printf("Error[NULL==pElf64_Ehdr]\n");
        return;
    }
    printf("\n---------ELF Header--------\n");
    printf("ELF Header:\n");
    printElf_Ehdr_e_ident(pElf64_Ehdr);
    printElf_Ehdr_Rest(pElf64_Ehdr);
    printf("---------------------------\n\n");
}

void printElf_Ehdr_e_ident(const Elf64_Ehdr *pElf64_Ehdr)
{
    printf("  Magic:");
    for (size_t i = 0; i < EI_NIDENT; i++)
    {
        printf("%02x", pElf64_Ehdr->e_ident[i]);
        if (i < EI_NIDENT - 1)
        {
            printf(" ");
        }
    }
    printf("\n");
}

void printElf_Ehdr_Rest(const Elf64_Ehdr *pElf64_Ehdr)
{
    printf("  %-35s%s\n", "Type:", ((ET_REL == pElf64_Ehdr->e_type) ? "Relocatable file" : "Others"));
    printf("  %-35s%s\n", "Machine:", ((EM_AARCH64 == pElf64_Ehdr->e_machine) ? "ARM AARCH64" : "Others"));
    printf("  %-35s0x%X\n", "Version:", pElf64_Ehdr->e_version);
    printf("  %-35s0x%lX\n", "Entry point address:", pElf64_Ehdr->e_entry);
    printf("  %-35s0x%lX\n", "Start of program headers:", pElf64_Ehdr->e_phoff);
    printf("  %-35s0x%lX\n", "Start of section headers:", pElf64_Ehdr->e_shoff);
    printf("  %-35s0x%X\n", "Flags:", pElf64_Ehdr->e_flags);
    printf("  %-35s%d(bytes)\n", "Size of this header:", pElf64_Ehdr->e_ehsize);
    printf("  %-35s%d(bytes)\n", "Size of program headers:", pElf64_Ehdr->e_phentsize);
    printf("  %-35s%d(bytes)\n", "Number of program headers:", pElf64_Ehdr->e_phnum);
    printf("  %-35s%d(bytes)\n", "Size of section headers:", pElf64_Ehdr->e_shentsize);
    printf("  %-35s%d\n", "Number of section headers:", pElf64_Ehdr->e_shnum);
    printf("  %-35s%d\n", "Section header string table index:", pElf64_Ehdr->e_shstrndx);
}

uint16_t getSectionNum(const Elf64_Ehdr *pElf64_Ehdr)
{
    return pElf64_Ehdr->e_shnum;
}
