#include <stdio.h>
#include "Ehdr.h"
#include "Shdr.h"
#include "readfile.h"

int main(int argc, char **argv)
{
    usage(argc, argv);

    int fd = -1;
    fd = read_obj(argv);

    struct stat file_status;
    size_t fsize;
    getStat(fd, &file_status, argv);

    char *file_mmbase = NULL;
    file_mmbase = mmapHelper(file_status.st_size, fd, argv);
    const Elf64_Ehdr *pElf64_Ehdr = (const Elf64_Ehdr *)file_mmbase;
    printElf_Ehdr(pElf64_Ehdr);

    uint16_t secNum = getSectionNum(pElf64_Ehdr);
    const Elf64_Shdr *pElf64_Shdr = (const Elf64_Shdr *)(file_mmbase + pElf64_Ehdr->e_shoff);
    printElf_Shdr(file_mmbase, secNum);

    readyExit(file_mmbase, file_status.st_size, fd);
    return 0;
}
