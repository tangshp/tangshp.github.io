#include <stdio.h>
#include "Ehdr.h"
#include "Shdr.h"
#include "Symtab.h"
#include "readfile.h"

int main(int argc, char **argv)
{
    usage(argc, argv);

    int fd = -1;
    fd = read_obj(argv);

    struct stat file_status;
    size_t fsize;
    getStat(fd, &file_status, argv);

    char *file_mmbase = NULL;
    file_mmbase = mmapHelper(file_status.st_size, fd, argv);
    const Elf64_Ehdr *pElf64_Ehdr = (const Elf64_Ehdr *)file_mmbase;
    printElf_Ehdr(pElf64_Ehdr);

    uint16_t secNum = getSectionNum(pElf64_Ehdr);
    const Elf64_Shdr *pElf64_Shdr = (const Elf64_Shdr *)(file_mmbase + pElf64_Ehdr->e_shoff);
    printElf_Shdr(file_mmbase, secNum);

    const Elf64_Shdr *pElf64_Shdr_symtab = getShdr(file_mmbase, secNum, ".symtab");
    const Elf64_Shdr *pElf64_Shdr_strtab = getShdr(file_mmbase, secNum, ".strtab");
    const char *symbolHeader = getSymbolHeader(file_mmbase, pElf64_Shdr_strtab);
    uint16_t numSymbol = getNumofSymbol(pElf64_Shdr_symtab);
    const Elf64_Sym *pElf64_Sym = getElf64_Sym(file_mmbase, pElf64_Shdr_symtab);

    printElf64_Sym(pElf64_Sym, numSymbol, symbolHeader);

    readyExit(file_mmbase, file_status.st_size, fd);
    return 0;
}
