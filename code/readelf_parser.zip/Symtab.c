#include <stddef.h>
#include <stdio.h>
#include "Symtab.h"

uint16_t getNumofSymbol(const Elf64_Shdr *pElf64_Shdr_symtab)
{
    return pElf64_Shdr_symtab->sh_size / sizeof(Elf64_Sym);
}

const Elf64_Sym *getElf64_Sym(const char *file_mmbase, const Elf64_Shdr *pElf64_Shdr_symtab)
{
    return (const Elf64_Sym *)(file_mmbase + pElf64_Shdr_symtab->sh_offset);
}

const char *getSymbolHeader(const char *file_mmbase, const Elf64_Shdr *pElf64_Shdr_strtab)
{
    return file_mmbase + pElf64_Shdr_strtab->sh_offset;
}

// #define STT_NOTYPE	0		/* Symbol type is unspecified */
// #define STT_OBJECT	1		/* Symbol is a data object */
// #define STT_FUNC	2		/* Symbol is a code object */
// #define STT_SECTION	3		/* Symbol associated with a section */
// #define STT_FILE	4		/* Symbol's name is file name */
// #define STT_COMMON	5		/* Symbol is a common data object */
// #define STT_TLS		6		/* Symbol is thread-local data object*/
// #define	STT_NUM		7		/* Number of defined types.  */
// #define STT_LOOS	10		/* Start of OS-specific */
// #define STT_GNU_IFUNC	10		/* Symbol is indirect code object */
// #define STT_HIOS	12		/* End of OS-specific */
// #define STT_LOPROC	13		/* Start of processor-specific */
// #define STT_HIPROC	15		/* End of processor-specific */
const char *symbolTypeStr(uint32_t symbolType)
{
    const char *type = NULL;
    switch (symbolType)
    {
    case STT_NOTYPE:
        type = "NOTYPE";
        break;
    case STT_SECTION:
        type = "SECTION";
        break;
    case STT_OBJECT:
        type = "OBJECT";
        break;
    case STT_FUNC:
        type = "FUNC";
        break;
    case STT_FILE:
        type = "FILE";
        break;
    case STT_COMMON:
        type = "COMMON";
        break;
    case STT_TLS:
        type = "TLS";
        break;
    case STT_NUM:
        type = "NUM";
        break;
    case STT_GNU_IFUNC:
        type = "LOOS_GNU_IFUNC";
        break;
    case STT_HIOS:
        type = "HIOS";
        break;
    case STT_LOPROC:
        type = "LOPROC";
        break;
    case STT_HIPROC:
        type = "HIPROC";
        break;

    default:
        type = "ERROR";
        break;
    }
    return type;
}

// #define STB_LOCAL	0		/* Local symbol */
// #define STB_GLOBAL	1		/* Global symbol */
// #define STB_WEAK	2		/* Weak symbol */
// #define	STB_NUM		3		/* Number of defined types.  */
// #define STB_LOOS	10		/* Start of OS-specific */
// #define STB_GNU_UNIQUE	10		/* Unique symbol.  */
// #define STB_HIOS	12		/* End of OS-specific */
// #define STB_LOPROC	13		/* Start of processor-specific */
// #define STB_HIPROC	15		/* End of processor-specific */
const char *symbolBindStr(uint32_t symbolBinding)
{
    const char *bind = NULL;
    switch (symbolBinding)
    {
    case STB_LOCAL:
        bind = "LOCAL";
        break;
    case STB_GLOBAL:
        bind = "GLOBAL";
        break;
    case STB_WEAK:
        bind = "WEAK";
        break;
    case STB_NUM:
        bind = "NUM";
        break;
    case STB_LOOS:
        bind = "LOCAL";
        break;
    case STB_HIOS:
        bind = "HIOS";
        break;
    case STB_LOPROC:
        bind = "LOPROC";
        break;
    case STB_HIPROC:
        bind = "HIPROC";
        break;

    default:
        bind = "ERROR";
        break;
    }
    return bind;
}

const char *symbolSHN(uint16_t shndx)
{
    const char *shn = NULL;

    switch (shndx)
    {
    case SHN_UNDEF:
        shn = "UNDEF";
        break;
    case SHN_LORESERVE:
        shn = "LORESERVE";
        break;
    case SHN_AFTER:
        shn = "AFTER";
        break;
    case SHN_HIPROC:
        shn = "HIPROC";
        break;
    case SHN_LOOS:
        shn = "LOOS";
        break;
    case SHN_HIOS:
        shn = "HIOS";
        break;
    case SHN_ABS:
        shn = "ABS";
        break;
    case SHN_COMMON:
        shn = "COM";
        break;
    case SHN_HIRESERVE:
        shn = "HIRESERVE";
        break;

    default:
        shn = NULL;
        break;
    }
    return shn;
}

void printElf64_Sym(const Elf64_Sym *pElf64_Sym, uint16_t numSymbol, const char *symbolHeader)
{
    const Elf64_Sym *pointer = NULL;
    const char *symbol = NULL;
    printf("\n\nSymbol table \'.symtab\' contains %u:\n", numSymbol);
    printf("   Num: %8s  %2s  %-8s  %-6s  %-7s  %-9s  %-15s\n", "Value", "Size", "Type", "Bind", "Vis", "Ndx", "Name");

    for (size_t i = 0; i < numSymbol; i++)
    {
        pointer = pElf64_Sym + i;
        symbol = symbolHeader + pointer->st_name;
        printf("    %2ld: ", i);
        printf("%08lX  ", pointer->st_value);
        printf("%2ld    ", pointer->st_size);

        uint32_t symbolType = ELF64_ST_TYPE(pointer->st_info);
        uint32_t symbolBinding = ELF64_ST_BIND(pointer->st_info);
        printf("%-8s  ", symbolTypeStr(symbolType));
        printf("%-6s  ", symbolBindStr(symbolBinding));
        printf("%7s  ", pointer->st_other == STV_DEFAULT ? "DEFAULT" : "Other");
        const char *shn = symbolSHN(pointer->st_shndx);
        if (NULL == shn)
        {
            printf("%-9d  ", pointer->st_shndx);
        }
        else
            printf("%-9s  ", shn);

        printf("%-15s", symbol);
        printf("\n");
    }
}
