#include <elf.h>

void printElf_Ehdr(const Elf64_Ehdr *pElf64_Ehdr);
void printElf_Ehdr_e_ident(const Elf64_Ehdr *pElf64_Ehdr);
void printElf_Ehdr_Rest(const Elf64_Ehdr *pElf64_Ehdr);

uint16_t getSectionNum(const Elf64_Ehdr *pElf64_Ehdr);