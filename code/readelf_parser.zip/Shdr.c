#include <stdio.h>
#include <stdbool.h>
#include <elf.h>
#include "Shdr.h"

/***
 * @autoAdd: true
 * @description:
 * @param {char} *file_mmbase : file first address
 * @param {size_t} i : i section
 * @return {*} address of section name
 */
const char *getSectionName(const char *file_mmbase, size_t i)
{
    static bool isFirst = true;

    const Elf64_Ehdr *pElf64_Ehdr = (const Elf64_Ehdr *)file_mmbase;
    // the i th section header address
    const Elf64_Shdr *pElf64_Shdr = getElf64_Shdr(file_mmbase, i);
    // section shstrtab header address
    const Elf64_Shdr *pShstrtab = (const Elf64_Shdr *)(file_mmbase + pElf64_Ehdr->e_shoff + pElf64_Ehdr->e_shstrndx * sizeof(Elf64_Shdr));

    uint64_t offset_shstrtab = pShstrtab->sh_offset;
    uint32_t offset_name = pElf64_Shdr->sh_name;

    // if (true == isFirst)
    // {
    // isFirst = false;
    // printf("\noffset_Elf64_Shdr[%ld]:%ld\n", i, (char *)pElf64_Shdr - (char *)pElf64_Ehdr);
    // printf("offset_Elf64_Shstrtab:%ld\n", (char *)pShstrtab - (char *)pElf64_Ehdr);
    //     printf("offset_shstrtab:%ld, offset_name:%d\n", offset_shstrtab, offset_name);
    // }
    return file_mmbase + offset_shstrtab + offset_name;
}

void printElf_Shdr(const char *file_mmbase, uint16_t secNum)
{
    const Elf64_Shdr *pElf64_Shdr = NULL;
    printf("Section Headers:\n");
    printf("  [Nr] %-15s   %-10s   %-8s %-6s %-6s %-2s %-3s %2s %3s %2s %-8s\n", "Name", "Type", "Addr", "Off", "Size", "ES", "Flg", "Lk", "Inf", "Al", "secHoff");
    printf("       %-15s   %-10s   %-8s %-6s %-6s %-2s %-3s %2s %3s %2s %-8s\n", "Unit", "Dec", "Hex", "Hex", "Hex", "He", "Hex", "De", "Dec", "De", "Hex");
    for (size_t i = 0; i < secNum; i++)
    {
        printf("  [%2ld] %-15s   ", i, getSectionName(file_mmbase, i));
        pElf64_Shdr = getElf64_Shdr(file_mmbase, i);
        printf("%-10d", pElf64_Shdr->sh_type);
        printf("   %08lX", pElf64_Shdr->sh_addr);
        printf(" %06lX", pElf64_Shdr->sh_offset);
        printf(" %06lX", pElf64_Shdr->sh_size);
        printf(" %02lX", pElf64_Shdr->sh_entsize);
        printf(" %-3lX", pElf64_Shdr->sh_flags);
        printf(" %-2d", pElf64_Shdr->sh_link);
        printf(" %-3d", pElf64_Shdr->sh_info);
        printf(" %-2ld", pElf64_Shdr->sh_addralign);
        printf(" %08lX", (char *)pElf64_Shdr - (char *)file_mmbase);
        printf("\n");
    }
}

const Elf64_Shdr *getElf64_Shdr(const char *file_mmbase, size_t i)
{
    const Elf64_Ehdr *pElf64_Ehdr = (const Elf64_Ehdr *)file_mmbase;
    // the i th section header address
    const Elf64_Shdr *pElf64_Shdr = (const Elf64_Shdr *)(file_mmbase + pElf64_Ehdr->e_shoff + i * sizeof(Elf64_Shdr));
    return pElf64_Shdr;
}