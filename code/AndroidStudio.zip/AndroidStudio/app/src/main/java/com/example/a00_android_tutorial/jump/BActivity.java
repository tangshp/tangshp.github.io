package com.example.a00_android_tutorial.jump;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.a00_android_tutorial.R;

public class BActivity extends Activity {
    private TextView mTv_msgFromA;
    private Button mJumpInBBtn;
    final private String TAG = "B-Activity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        Log.i(TAG, "onNewIntent: taskId:" + getTaskId() + "hashCode:" + hashCode());
        logTaskName();
        mTv_msgFromA = (TextView) findViewById(R.id.tv_msgFromA);
        mJumpInBBtn  = (Button)findViewById(R.id.jumpInBBtn);

        // 数据接受
        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("name");
        Integer id  = bundle.getInt("id");
        mTv_msgFromA.setText("name:" + name + ", id:" + id);

//        mJumpInBBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent();
//                Bundle bundleOnClick = new Bundle();
//                bundleOnClick.putString("title", "message from B");
//                intent.putExtras(bundleOnClick);
//                setResult(Activity.RESULT_OK, intent);
//                finish();
//            }
//        });
    }

    private void logTaskName()
    {
        try{
            ActivityInfo info = getPackageManager().getActivityInfo(getComponentName(), PackageManager.GET_META_DATA);
            Log.i(TAG, "logTaskName: " + info.taskAffinity);
        }catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i(TAG, "onNewIntent: taskId:" + getTaskId() + "hashCode:" + hashCode());
        logTaskName();
    }
}
