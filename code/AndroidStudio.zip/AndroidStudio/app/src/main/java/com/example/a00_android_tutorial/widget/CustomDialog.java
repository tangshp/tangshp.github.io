package com.example.a00_android_tutorial.widget;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.PointerIcon;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.a00_android_tutorial.R;

public class CustomDialog extends Dialog implements View.OnClickListener {
    private TextView mTvTitle, mTvContent, mTvConfirm, mTvCancel;
    private IOnCancelListener iOnCancelListener;
    private IOnConfirmListener iOnConfirmListener;

    public CustomDialog setmTitle(String mTitle) {
        this.mTitle = mTitle;
        return this;
    }

    public CustomDialog setmMessage(String mMessage) {
        this.mMessage = mMessage;
        return this;
    }

    public CustomDialog setmCancel(String mCancel, IOnCancelListener iOnCancelListener) {
        this.mCancel = mCancel;
        this.iOnCancelListener = iOnCancelListener;
        return this;
    }

    public CustomDialog setmConfirm(String mConfirm, IOnConfirmListener iOnConfirmListener) {
        this.mConfirm = mConfirm;
        this.iOnConfirmListener = iOnConfirmListener;
        return this;
    }

    private String mTitle, mMessage, mCancel, mConfirm;

    public CustomDialog(@NonNull Context context) {
        super(context);
    }

    public CustomDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_custom_dialog);
        // 设置宽度
        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay();
        WindowManager.LayoutParams p = getWindow().getAttributes();
        Point size = new Point();
        d.getSize(size);
        p.width = (int)(size.x * 0.8);
        getWindow().setAttributes(p);

        mTvTitle   = (TextView) findViewById(R.id.tv_title);
        mTvContent = (TextView) findViewById(R.id.tv_content);
        mTvConfirm = (TextView) findViewById(R.id.tv_btn_confirm);
        mTvCancel  = (TextView) findViewById(R.id.tv_btn_cancel);

        mTvTitle.setText(mTitle);
        mTvContent.setText(mMessage);
        mTvConfirm.setText(mConfirm);
        mTvCancel.setText(mCancel);

        mTvCancel.setOnClickListener(this);
        mTvConfirm.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.tv_btn_cancel:
                if(this.iOnCancelListener != null)
                {
                    iOnCancelListener.onCancel(this);
                }
                break;
            case R.id.tv_btn_confirm:
                if(this.iOnConfirmListener != null)
                {
                    iOnConfirmListener.onConfirm(this);
                }
                break;
        }
    }

    public interface IOnCancelListener{
        void onCancel(CustomDialog dialog);
    }

    public interface IOnConfirmListener{
        void onConfirm(CustomDialog dialog);
    }
}
