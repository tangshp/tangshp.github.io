package com.example.a00_android_tutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.a00_android_tutorial.widget.CustomDialog;

public class CustomDialogActivity extends AppCompatActivity {
    private Button mBtnDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_dialog);

        mBtnDialog = (Button) findViewById(R.id.customDialogBtn);
        mBtnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomDialog customDialog = new CustomDialog(CustomDialogActivity.this);
                customDialog.setmTitle("提醒")
                        .setmMessage("确认消息内容")
                        .setmCancel("取消(cancel)", new CustomDialog.IOnCancelListener() {
                            @Override
                            public void onCancel(CustomDialog dialog) {
                                Toast.makeText(CustomDialogActivity.this, "cancel callback", Toast.LENGTH_LONG).show();
                                dialog.dismiss();
                            }
                        })
                        .setmConfirm("确认(confirm)", new CustomDialog.IOnConfirmListener() {
                            @Override
                            public void onConfirm(CustomDialog dialog) {
                                Toast.makeText(CustomDialogActivity.this, "confirm callback", Toast.LENGTH_LONG).show();
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        });
    }
}