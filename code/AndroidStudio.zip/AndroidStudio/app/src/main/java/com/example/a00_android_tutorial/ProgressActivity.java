package com.example.a00_android_tutorial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class ProgressActivity extends AppCompatActivity {
    private ProgressBar mPb;
    private Button mPbBtn;

    private Button mBtn_progress_dialog1, mBtn_progress_dialog2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        mPb = (ProgressBar) findViewById(R.id.progressBarHorizontal);
        mPbBtn = (Button) findViewById(R.id.pbBtn);

        mPbBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("TUT", "handleMessage: " + mPb.getProgress());
                handler.sendEmptyMessage(0);// 给 handler 发消息
            }
        });

        buttonInit();


    }

    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            // 处理 hendler 的消息
            super.handleMessage(msg);
            Log.i("TUT", "handleMessage: " + mPb.getProgress());
            if(mPb.getProgress() < 100)
            {
                handler.postDelayed(runnable, 500);// 给runnable发延时消息
            }
            else {
                Toast.makeText(ProgressActivity.this, "finish", Toast.LENGTH_LONG).show();
            }
        }
    };

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            mPb.setProgress(mPb.getProgress() + 1);
            handler.sendEmptyMessage(0);
        }
    };

    void buttonInit()
    {
        mBtn_progress_dialog1 = (Button) findViewById(R.id.btn_progress_dialog1);
        mBtn_progress_dialog2 = (Button) findViewById(R.id.btn_progress_dialog2);

        mBtn_progress_dialog1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProgressDialog progressDialog = new ProgressDialog(ProgressActivity.this);
                progressDialog.setTitle("提示");
                progressDialog.setMessage("正在加载...");
                progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialogInterface) {
                        Toast.makeText(ProgressActivity.this, "onCancel finish" , Toast.LENGTH_LONG).show();
                    }
                });
                progressDialog.setCancelable(false);
                progressDialog.show();
            }
        });

        mBtn_progress_dialog2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProgressDialog progressDialog = new ProgressDialog(ProgressActivity.this);
                progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progressDialog.setTitle("提示");
                progressDialog.setMessage("正在加载...");
                progressDialog.setButton(DialogInterface.BUTTON_POSITIVE, "good", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(ProgressActivity.this, "good" , Toast.LENGTH_LONG).show();
                    }
                });
                progressDialog.show();
            }
        });
    }
}