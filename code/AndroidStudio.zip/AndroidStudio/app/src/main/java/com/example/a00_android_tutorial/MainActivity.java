package com.example.a00_android_tutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.a00_android_tutorial.jump.AActivity;

public class MainActivity extends AppCompatActivity {
    private Button mAlertDialogBtn;
    private Button mProgressBtn;
    private Button mCustomDialogBtn;
    private Button mPopupBtn;
    private Button mTestActivityBtn;
    private Button mJumpBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        OnClick onClick = new OnClick();

        mAlertDialogBtn = (Button) findViewById(R.id.alertDialogBtn);
        mProgressBtn = (Button) findViewById(R.id.progressBtn);
        mCustomDialogBtn = (Button) findViewById(R.id.customDialogBtn);
        mPopupBtn = (Button) findViewById(R.id.popupBtn);
        mTestActivityBtn = (Button) findViewById(R.id.testActivityBtn);
        mJumpBtn = (Button) findViewById(R.id.jumpBtn);

        mAlertDialogBtn.setOnClickListener(onClick);
        mProgressBtn.setOnClickListener(onClick);
        mCustomDialogBtn.setOnClickListener(onClick);
        mPopupBtn.setOnClickListener(onClick);
        mTestActivityBtn.setOnClickListener(onClick);
        mJumpBtn.setOnClickListener(onClick);
    }

    class OnClick implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent intent = null;
            switch (view.getId())
            {
                case R.id.alertDialogBtn:
                    intent = new Intent(MainActivity.this, AlertDialogActivity.class);
                    break;

                case R.id.progressBtn:
                    intent = new Intent(MainActivity.this, ProgressActivity.class);
                    break;

                case R.id.customDialogBtn:
                    intent = new Intent(MainActivity.this, CustomDialogActivity.class);
                    break;

                case R.id.popupBtn:
                    intent = new Intent(MainActivity.this, PopupWindowActivity.class);
                    break;

                case R.id.testActivityBtn:
                    intent = new Intent(MainActivity.this, TestActivity.class);
                    break;
                case R.id.jumpBtn:
                intent = new Intent(MainActivity.this, AActivity.class);
                break;
                default:
                    break;
            }
            startActivity(intent);
        }
    }
}