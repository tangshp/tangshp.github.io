package com.example.a00_android_tutorial;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AlertDialogActivity extends AppCompatActivity {
    private Button mDialog1Btn;
    private Button mDialog2Btn;
    private Button mDialog3Btn;
    private Button mDialog4Btn;
    private Button mCustomBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_dialog);

        mDialog1Btn = (Button) findViewById(R.id.dialog1Btn);
        mDialog2Btn = (Button) findViewById(R.id.dialog2Btn);
        mDialog3Btn = (Button) findViewById(R.id.dialog3Btn);
        mDialog4Btn = (Button) findViewById(R.id.dialog4Btn);
        mCustomBtn = (Button) findViewById(R.id.customBtn);

        OnClick onClick = new OnClick();
        mDialog1Btn.setOnClickListener(onClick);
        mDialog2Btn.setOnClickListener(onClick);
        mDialog3Btn.setOnClickListener(onClick);
        mDialog4Btn.setOnClickListener(onClick);
        mCustomBtn.setOnClickListener(onClick);
    }

    class OnClick implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            switch (view.getId())
            {
                case R.id.dialog1Btn:
                    doDialog1Btn();
                    break;
                case R.id.dialog2Btn:
                    doDialog2Btn();
                    break;
                case R.id.dialog3Btn:
                    doDialog3Btn();
                    break;
                case R.id.dialog4Btn:
                    doDialog4Btn();
                    break;
                case R.id.customBtn:
                    doCustomBtn();
                    break;
            }
        }

        void doDialog1Btn()
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(AlertDialogActivity.this);
            builder.setTitle("请回答")
                    .setMessage("你觉得课程怎么样?")
                    .setPositiveButton("不错", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "thank you", Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNeutralButton("还行", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "thank you, ...", Toast.LENGTH_LONG).show();
                        }

                    })
                    .setNegativeButton("不好", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "sorry, ...", Toast.LENGTH_LONG).show();
                        }
                    })
                    .setIcon(R.drawable.search)
                    .show();
        }

        void doDialog2Btn()
        {
            String[]  optionsArr = new String[]{"男", "女", "其它"};
            AlertDialog.Builder builder = new AlertDialog.Builder(AlertDialogActivity.this);
            builder.setIcon(R.drawable.search)
                    .setTitle("这是一道选择题")
                    .setItems(optionsArr, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "you select result is " + optionsArr[i], Toast.LENGTH_LONG).show();
                        }
                    })
                    .show();
        }

        void doDialog3Btn()
        {
            String[]  optionsArr = new String[]{"男", "女", "其它"};
            AlertDialog.Builder builder = new AlertDialog.Builder(AlertDialogActivity.this);
            builder.setIcon(R.drawable.search)
                    .setTitle("这是另外一道选择题")
                    .setSingleChoiceItems(optionsArr, 0, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "you select result is " + optionsArr[i], Toast.LENGTH_LONG).show();
                            dialogInterface.dismiss();
                        }
                    })
                    .setCancelable(false)
                    .show();
                    // checkedItem is default selected
        }

        void doDialog4Btn()
        {
            String[]  optionsArr = new String[]{"湖南省", "湖北省", "安徽省", "江西省", "河南省","山西省"};
            boolean[] defaultSelectArr = new boolean[]{true, false, false, false, false, false};
            AlertDialog.Builder builder = new AlertDialog.Builder(AlertDialogActivity.this);
            builder.setTitle("这是一道多选题")
                    .setMultiChoiceItems(optionsArr, defaultSelectArr, new DialogInterface.OnMultiChoiceClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                            Toast.makeText(AlertDialogActivity.this, "you select result is " + optionsArr[i] + ":" + b, Toast.LENGTH_LONG).show();
                        }
                    })
                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "确定", Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(AlertDialogActivity.this, "取消", Toast.LENGTH_LONG).show();
                        }
                    })
                    .show();
        }

        void doCustomBtn()
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(AlertDialogActivity.this);
            View view = LayoutInflater.from(AlertDialogActivity.this).inflate(R.layout.layout_dialog, null);

            EditText etUserName = (EditText)view.findViewById(R.id.et_userName);
            EditText etUserPass = (EditText)view.findViewById(R.id.et_userPass);
            Button loginBtn = (Button)view.findViewById(R.id.loginBtn);

            loginBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String userName = etUserName.getText().toString();
                    String userPass = etUserPass.getText().toString();
                    Toast.makeText(AlertDialogActivity.this, "userName:" + userName + ", userPass:" + userPass, Toast.LENGTH_LONG).show();
                }
            });
            builder.setTitle("这是一个自定义弹框").setView(view).setCancelable(false).show();
        }
    }




}