package com.example.a00_android_tutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class PopupWindowActivity extends AppCompatActivity {
    private Button mPopup_show_Btn;
    private PopupWindow mPop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup_window);

        mPopup_show_Btn = (Button) findViewById(R.id.popup_show_Btn);
        mPopup_show_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View v = getLayoutInflater().inflate(R.layout.layout_pop, null);
                mPop = new PopupWindow(v, mPopup_show_Btn.getWidth(), ViewGroup.LayoutParams.WRAP_CONTENT);

                TextView tv_item1 = (TextView) v.findViewById(R.id.tv_item1);
                tv_item1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mPop.dismiss();
                        Toast.makeText(PopupWindowActivity.this, "item1", Toast.LENGTH_LONG).show();
                    }
                });
                TextView tv_item2 = (TextView) v.findViewById(R.id.tv_item2);
                tv_item2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mPop.dismiss();
                        Toast.makeText(PopupWindowActivity.this, "item2", Toast.LENGTH_LONG).show();
                    }
                });
                TextView tv_item3 = (TextView) v.findViewById(R.id.tv_item3);
                tv_item3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mPop.dismiss();
                        Toast.makeText(PopupWindowActivity.this, "item3", Toast.LENGTH_LONG).show();
                    }
                });

                mPop.setOutsideTouchable(true);
                mPop.setFocusable(true);
                mPop.setAnimationStyle(R.style.PopupAnimation);
                mPop.showAsDropDown(mPopup_show_Btn);
            }
        });
    }
}