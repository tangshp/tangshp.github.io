Activity的四种启动模式

* `standard`:标准模式, 默认, 不管有没有**都创建新实例**
* `singleTop`:`Task`栈顶复用模式, 栈顶是当前要创建的实例则不创建新实例, 否则创建新实例
* `singleTask`:`Task`栈内服用模式, 栈内有当前要创建的实例则不创建新实例, 否则创建新实例
* `singleInstance`:全局单例模式

`Activity`是由任务栈管理的, 每启动一个`Activity`, 就会被放入在栈内, 按返回键, 就会从栈顶移除一个`Activity`